package edu.towson.cis.cosc603.project2.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Class Die.
 */
public class Die {
	
	/**
	 * Gets the roll.
	 *
	 * @return the roll
	 */
	public int getRoll() {
		return (int)(Math.random() * 6) + 1;
	}
}
