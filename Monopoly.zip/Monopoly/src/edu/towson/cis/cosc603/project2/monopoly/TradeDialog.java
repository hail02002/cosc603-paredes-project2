package edu.towson.cis.cosc603.project2.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Interface TradeDialog.
 */
public interface TradeDialog {
    
    /**
     * Gets the trade deal.
     *
     * @return the trade deal
     */
    TradeDeal getTradeDeal();
}
