package edu.towson.cis.cosc603.project2.monopoly.gui;

import edu.towson.cis.cosc603.project2.monopoly.Cell;

public interface CellInfoFormatter {
    public String format(Cell cell);
}
