package edu.towson.cis.cosc603.project2.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Interface RespondDialog.
 */
public interface RespondDialog {
    
    /**
     * Gets the response.
     *
     * @return the response
     */
    boolean getResponse();
}
