package edu.towson.cis.cosc603.project2.monopoly;

/**
 * The Interface IOwnable.
 */
public interface IOwnable {

}