package edu.towson.cis.cosc603.project2.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Class CardCell.
 */
public class CardCell extends Cell {
    
    /**
     * Instantiates a new card cell.
     *
     * @param type the type
     * @param name the name
     */
    public CardCell(int type, String name) {
        setName(name);
        this.type = type;
    }
}
