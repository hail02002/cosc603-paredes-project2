package edu.towson.cis.cosc603.project2.monopoly;

// TODO: Auto-generated Javadoc
/**
 * The Class MockRespondDialog.
 */
public class MockRespondDialog implements RespondDialog {
    
    /**
     * Instantiates a new mock respond dialog.
     *
     * @param deal the deal
     */
    public MockRespondDialog(TradeDeal deal) {
    }

    /* (non-Javadoc)
     * @see edu.towson.cis.cosc442.project1.monopoly.RespondDialog#getResponse()
     */
    public boolean getResponse() {
        return true;
    }
}
